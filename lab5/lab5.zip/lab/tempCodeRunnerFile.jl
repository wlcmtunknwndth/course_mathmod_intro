xlabel = "время",
    ylabel = "численность"